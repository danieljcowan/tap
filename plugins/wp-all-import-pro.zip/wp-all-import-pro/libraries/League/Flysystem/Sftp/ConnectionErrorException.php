<?php

namespace League\Flysystem\Sftp;

class ConnectionErrorException extends \LogicException implements SftpAdapterException
{
}
