<?php 
/**
 * Admin Help page
 * 
 * @author Pavel Kulbakin <p.kulbakin@gmail.com>
 */
class PMXE_Admin_Feedback extends PMXE_Controller_Admin {
	
	public function index_action() {
		$this->render();
	}
}